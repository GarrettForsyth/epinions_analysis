package main.java; 

public class Main {

	public static void main(String[] args) {
	    //epinionsGraph = EpinionsGraph.createUnSignedGraphFrom("../soc-sign-epinions.txt");	
		//getSCCs(epinionsGraph);
		//BetweennessCentrality.computeBetweennessCentrality(epinionsGraph, largestSCC);
		//BetweennessCentrality.readBCFromFileAndSortAndWrite("../epinions_betweenness_centrality_reversed.txt");
	    System.out.println("hello world");	
	}
	
	

	
	
    
	

	
	
	
	
	
	
	
	

	
	

	
	
	
	
	
	
    
	

	

	

	
	
	
	
	
	
	
	
	
	
}
